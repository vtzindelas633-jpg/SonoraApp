# SONORA — Player de Música Premium (Android)

Aplicativo Android nativo desenvolvido em **Kotlin + Jetpack Compose + AndroidX Media3 (ExoPlayer) + Room**.

## Como gerar o APK sem precisar de PC (via GitHub Actions)

1. Crie um repositório no GitHub (pelo navegador do celular).
2. Envie (faça upload) de todos os arquivos extraídos deste `.zip` para a raiz do repositório (incluindo a pasta `.github/workflows/build-apk.yml`).
3. Abra a aba **Actions** no GitHub.
4. Clique no workflow **Build Sonora APK** e aguarde a compilação automática (~2 a 4 minutos).
5. Ao concluir, baixe o artefato **Sonora-Debug-APK**, extraia o `app-debug.apk` e instale no seu Android.

## Recursos Implementados

- **Motor de Áudio Real (`Media3` / `ExoPlayer`):** Reprodução em segundo plano, controles na tela de bloqueio, notificação persistente, controle via fones Bluetooth, *Gapless Playback*, Crossfade, Velocidade (0.75x–2.0x) e Temporizador de desligamento.
- **Equalizador de Hardware:** 5 bandas reais, 8 presets (Flat, Rock, Pop, Jazz, Clássica, Eletrônica, Hip-Hop, Voz), Bass Boost e Normalização de volume (`LoudnessEnhancer`).
- **Arquivos Locais Offline:** Scanner automático de MP3, FLAC, WAV, AAC, M4A, OGG e OPUS com leitura de metadados e capas.
- **Catálogo Online Legal:** Streaming de faixas completas via **Audius API** + Podcasts reais via **iTunes API / RSS**.
- **Letras Sincronizadas:** Integração com **LRCLIB API** com destaque da linha atual, rolagem automática e toque para avançar para o trecho.
- **Downloads Reais:** Armazenamento interno real para reprodução offline, trava de Wi-Fi e controle de espaço usado.
- **Biblioteca & Playlists:** Banco local SQLite (**Room**) com Favoritos, Playlists (públicas, privadas, colaborativas, pastas), Fila editável e Histórico.
- **IA Musical & DJ Virtual:** Gerador de playlists inteligente (motor local + suporte opcional à **Gemini API**) e DJ com voz via Android TextToSpeech.
- **Retrospectiva & Jam:** Estatísticas reais de audição compartilháveis e criação de sessões Jam por código.
- **Backend Pronto:** `supabase/schema.sql` e `supabase/functions/ai-playlist/index.ts` inclusos para deploy em nuvem.
