import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

serve(async (req) => {
  try {
    const { prompt, catalog } = await req.json();
    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "GEMINI_API_KEY not configured on server" }), { status: 500 });
    }
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `Você é um curador musical especialista do app Sonora. Pedido do usuário: "${prompt}". Catálogo disponível (JSON): ${JSON.stringify(catalog)}. Retorne APENAS um JSON válido no formato {"name": "Nome da Playlist", "explanation": "Explicação curta", "trackIds": ["id1", "id2"]}.`
            }]
          }]
        })
      }
    );
    const data = await response.json();
    return new Response(JSON.stringify(data), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 400 });
  }
});
