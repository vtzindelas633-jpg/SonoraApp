package com.sonora.app.ui.social

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sonora.app.ui.SonoraViewModel

@Composable
fun AiAndSocialScreen(viewModel: SonoraViewModel) {
    val context = LocalContext.current
    val aiSuggestion by viewModel.aiSuggestion.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val playback by viewModel.playbackState.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val jam by viewModel.jamState.collectAsState()

    var prompt by remember { mutableStateOf("") }
    var jamCodeInput by remember { mutableStateOf("") }

    val quickPrompts = listOf(
        "Rock para academia",
        "Músicas tristes para noite",
        "Animadas para viagem",
        "Parecidas com minhas favoritas"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("IA Musical, Jam & Retrospectiva", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
        }

        // 1. Playlist com IA
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Playlist com IA", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        placeholder = { Text("Ex: Músicas animadas para corrida...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(quickPrompts) { qp ->
                            AssistChip(onClick = { prompt = qp; viewModel.generateAiPlaylist(qp) }, label = { Text(qp) })
                        }
                    }
                    Button(
                        onClick = { viewModel.generateAiPlaylist(prompt) },
                        enabled = !isAiLoading && prompt.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isAiLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Text("Gerar Playlist Inteligente")
                    }

                    aiSuggestion?.let { sug ->
                        HorizontalDivider()
                        Text(sug.playlistName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(sug.explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = { viewModel.playTrackList(sug.tracks, 0) },
                                enabled = sug.tracks.isNotEmpty()
                            ) {
                                Icon(Icons.Rounded.PlayArrow, null)
                                Spacer(Modifier.width(4.dp))
                                Text("Tocar (${sug.tracks.size})")
                            }
                            OutlinedButton(
                                onClick = { viewModel.saveAiSuggestionAsPlaylist() },
                                enabled = sug.tracks.isNotEmpty()
                            ) {
                                Text("Salvar na Biblioteca")
                            }
                        }
                    }
                }
            }
        }

        // 2. DJ Virtual com IA
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DJ Sonora (IA)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Anuncia faixas e cria transições com voz entre músicas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = playback.djModeEnabled,
                        onCheckedChange = { viewModel.playerController.setDjMode(it) }
                    )
                }
            }
        }

        // 3. Sessão Compartilhada (Jam)
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Groups, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Sessão Compartilhada (Jam)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    if (!jam.isActive) {
                        Button(onClick = { viewModel.startJamSession() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Iniciar Nova Sessão Jam")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = jamCodeInput,
                                onValueChange = { jamCodeInput = it },
                                placeholder = { Text("Código da sessão") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            FilledTonalButton(onClick = { viewModel.joinJamSession(jamCodeInput) }) {
                                Text("Entrar")
                            }
                        }
                    } else {
                        Text("Código da Sessão: ${jam.joinCode}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                        Text("Participantes: ${jam.participants.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = {
                                context.startActivity(viewModel.shareTextIntent("Convite Sonora Jam", "Entre na minha sessão musical no Sonora! Código: ${jam.joinCode}"))
                            }) {
                                Icon(Icons.Rounded.Share, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Convidar")
                            }
                            OutlinedButton(onClick = { viewModel.leaveJamSession() }) {
                                Text("Encerrar")
                            }
                        }
                    }
                }
            }
        }

        // 4. Estatísticas & Retrospectiva Anual (Wrapped)
        item {
            val totalMinutes = (stats.totalListeningMs / 60_000L)
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.BarChart, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Retrospectiva Sonora", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        IconButton(onClick = {
                            val summary = buildString {
                                appendLine("Minha Retrospectiva Sonora:")
                                appendLine("Total de reproduções: ${stats.totalPlays}")
                                appendLine("Tempo ouvido: $totalMinutes minutos")
                                appendLine("Top Artista: ${stats.topArtists.firstOrNull()?.first ?: "—"}")
                                append("Álbum Favorito: ${stats.favoriteAlbum}")
                            }
                            context.startActivity(viewModel.shareTextIntent("Retrospectiva Sonora", summary))
                        }) {
                            Icon(Icons.Rounded.Share, "Compartilhar retrospectiva")
                        }
                    }
                    Text("Total de reproduções: ${stats.totalPlays}  •  $totalMinutes min ouvidos", style = MaterialTheme.typography.bodyMedium)
                    Text("Álbum favorito: ${stats.favoriteAlbum}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    if (stats.topArtists.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text("Top Artistas", fontWeight = FontWeight.SemiBold)
                        stats.topArtists.forEachIndexed { i, (artist, count) ->
                            Text("${i + 1}. $artist ($count plays)", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (stats.topTracks.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text("Top Músicas", fontWeight = FontWeight.SemiBold)
                        stats.topTracks.take(5).forEachIndexed { i, (track, count) ->
                            Text("${i + 1}. ${track.title} — ${track.artist} ($count)", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
