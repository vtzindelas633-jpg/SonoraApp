package com.sonora.app.data.remote

import com.sonora.app.domain.model.Track
import com.sonora.app.domain.model.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class PodcastShow(
    val id: String,
    val title: String,
    val author: String,
    val artworkUrl: String,
    val feedUrl: String,
    val genre: String
)

class PodcastApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun searchPodcasts(query: String = "tecnologia brasil", limit: Int = 12): List<PodcastShow> =
        withContext(Dispatchers.IO) {
            runCatching {
                val enc = URLEncoder.encode(query.ifBlank { "podcast" }, "UTF-8")
                val url = "https://itunes.apple.com/search?media=podcast&term=$enc&limit=$limit&country=BR"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use emptyList()
                    val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("results") ?: return@use emptyList()
                    val shows = mutableListOf<PodcastShow>()
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val feedUrl = obj.optString("feedUrl")
                        if (feedUrl.isBlank()) continue
                        shows.add(
                            PodcastShow(
                                id = obj.optString("collectionId"),
                                title = obj.optString("collectionName"),
                                author = obj.optString("artistName"),
                                artworkUrl = obj.optString("artworkUrl600").ifBlank { obj.optString("artworkUrl100") },
                                feedUrl = feedUrl,
                                genre = obj.optString("primaryGenreName", "Podcast")
                            )
                        )
                    }
                    shows
                }
            }.getOrDefault(emptyList())
        }

    suspend fun fetchEpisodes(show: PodcastShow, maxEpisodes: Int = 15): List<Track> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url(show.feedUrl).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use emptyList()
                val xml = resp.body?.string().orEmpty()
                parseRssEpisodes(xml, show, maxEpisodes)
            }
        }.getOrDefault(emptyList())
    }

    private fun parseRssEpisodes(xml: String, show: PodcastShow, maxEpisodes: Int): List<Track> {
        val episodes = mutableListOf<Track>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml))

        var insideItem = false
        var currentTitle = ""
        var currentAudioUrl = ""
        var eventType = parser.eventType

        while (eventType != XmlPullParser.END_DOCUMENT && episodes.size < maxEpisodes) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name.lowercase()) {
                        "item" -> {
                            insideItem = true
                            currentTitle = ""
                            currentAudioUrl = ""
                        }
                        "title" -> if (insideItem && currentTitle.isBlank()) {
                            currentTitle = parser.nextText().trim()
                        }
                        "enclosure" -> if (insideItem) {
                            val url = parser.getAttributeValue(null, "url").orEmpty()
                            if (url.isNotBlank()) currentAudioUrl = url
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true) && insideItem) {
                        insideItem = false
                        if (currentAudioUrl.isNotBlank()) {
                            episodes.add(
                                Track(
                                    id = "pod_${show.id}_${episodes.size}_${currentTitle.hashCode()}",
                                    title = currentTitle.ifBlank { "Episódio ${episodes.size + 1}" },
                                    artist = show.author,
                                    album = show.title,
                                    genre = "Podcast",
                                    durationMs = 1_800_000L,
                                    artworkUri = show.artworkUrl,
                                    mediaUri = currentAudioUrl,
                                    source = TrackSource.PODCAST
                                )
                            )
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return episodes
    }
}
