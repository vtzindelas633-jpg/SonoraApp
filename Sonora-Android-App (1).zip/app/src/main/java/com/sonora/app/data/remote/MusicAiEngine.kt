package com.sonora.app.data.remote

import com.sonora.app.domain.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiPlaylistSuggestion(
    val playlistName: String,
    val explanation: String,
    val tracks: List<Track>
)

class MusicAiEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun generatePlaylist(
        prompt: String,
        availableCatalog: List<Track>,
        geminiApiKey: String
    ): AiPlaylistSuggestion = withContext(Dispatchers.IO) {
        if (availableCatalog.isEmpty()) {
            return@withContext AiPlaylistSuggestion(
                playlistName = "Playlist Sonora IA",
                explanation = "Nenhuma faixa disponível no catálogo atual. Importe músicas locais ou conecte-se à internet.",
                tracks = emptyList()
            )
        }

        if (geminiApiKey.isNotBlank()) {
            val geminiResult = tryGeminiApi(prompt, availableCatalog, geminiApiKey)
            if (geminiResult != null && geminiResult.tracks.isNotEmpty()) {
                return@withContext geminiResult
            }
        }

        // Motor local inteligente baseado em intenção, humor, gênero e metadados reais
        buildSmartLocalSuggestion(prompt, availableCatalog)
    }

    private fun tryGeminiApi(prompt: String, catalog: List<Track>, apiKey: String): AiPlaylistSuggestion? {
        return runCatching {
            val compactCatalog = JSONArray().apply {
                catalog.take(50).forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id)
                        put("title", t.title)
                        put("artist", t.artist)
                        put("genre", t.genre)
                    })
                }
            }
            val instruction = """
                Você é o curador musical do app Sonora.
                Pedido do usuário: "$prompt"
                Catálogo real disponível: $compactCatalog
                Responda APENAS um JSON puro sem markdown no formato:
                {"name":"Nome criativo","explanation":"Breve explicação em português","trackIds":["id1","id2"]}
            """.trimIndent()

            val payload = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", instruction)))
                }))
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
            val req = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = JSONObject(resp.body?.string().orEmpty())
                val rawText = body.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .replace("```json", "")
                    .replace("```", "")
                    .trim()

                val parsed = JSONObject(rawText)
                val idsJson = parsed.getJSONArray("trackIds")
                val ids = mutableSetOf<String>()
                for (i in 0 until idsJson.length()) ids.add(idsJson.getString(i))

                val selected = catalog.filter { it.id in ids }
                AiPlaylistSuggestion(
                    playlistName = parsed.optString("name", "Mix Sonora IA"),
                    explanation = parsed.optString("explanation", "Seleção gerada via Gemini IA."),
                    tracks = selected.ifEmpty { catalog.take(10) }
                )
            }
        }.getOrNull()
    }

    private fun buildSmartLocalSuggestion(prompt: String, catalog: List<Track>): AiPlaylistSuggestion {
        val lower = prompt.lowercase()
        val keywords = when {
            lower.contains("academia") || lower.contains("treino") || lower.contains("rock") ->
                listOf("rock", "electronic", "hip", "rap", "trap", "metal", "workout", "energetic")
            lower.contains("triste") || lower.contains("noite") || lower.contains("dormir") || lower.contains("calma") ->
                listOf("ambient", "lo-fi", "lofi", "acoustic", "jazz", "classical", "chill", "sad")
            lower.contains("viagem") || lower.contains("animad") || lower.contains("festa") ->
                listOf("pop", "dance", "house", "funk", "electronic", "edm")
            lower.contains("favorit") -> listOf("FAVORITES_ONLY")
            else -> lower.split(" ").filter { it.length > 2 }
        }

        val matched = if ("FAVORITES_ONLY" in keywords) {
            catalog.filter { it.isFavorite }.ifEmpty { catalog.sortedByDescending { it.playCount }.take(12) }
        } else {
            val scored = catalog.map { track ->
                val text = "${track.title} ${track.artist} ${track.album} ${track.genre}".lowercase()
                val score = keywords.count { kw -> text.contains(kw) } + (if (track.isFavorite) 1 else 0)
                track to score
            }.sortedByDescending { it.second }

            val strong = scored.filter { it.second > 0 }.map { it.first }
            strong.ifEmpty { catalog.shuffled() }.take(15)
        }

        val title = "Mix IA: ${prompt.trim().replaceFirstChar { it.uppercase() }.take(28)}"
        val explanation = "Selecionamos ${matched.size} faixas reais do seu catálogo e tendências combinando com o clima '$prompt'."
        return AiPlaylistSuggestion(title, explanation, matched)
    }

    fun buildDjCommentary(track: Track): String {
        return "Na sequência do DJ Sonora, você ouve ${track.title}, de ${track.artist}. Aproveite o som!"
    }
}
