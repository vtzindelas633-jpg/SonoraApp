package com.sonora.app.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.sonora.app.domain.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class SonoraDownloadManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val downloadDir: File
        get() = File(context.filesDir, "downloads").apply { if (!exists()) mkdirs() }

    fun isOnWifi(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    suspend fun downloadTrack(track: Track, wifiOnly: Boolean): Result<String> = withContext(Dispatchers.IO) {
        if (wifiOnly && !isOnWifi()) {
            return@withContext Result.failure(IllegalStateException("Download bloqueado: ative o Wi-Fi ou desative 'Somente Wi-Fi' nos ajustes."))
        }
        runCatching {
            val safeName = track.id.replace(Regex("[^a-zA-Z0-9_-]"), "_") + ".mp3"
            val targetFile = File(downloadDir, safeName)
            val request = Request.Builder().url(track.mediaUri).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("Erro HTTP ${response.code} ao baixar faixa")
                val body = response.body ?: error("Corpo de áudio vazio")
                body.byteStream().use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output, bufferSize = 16 * 1024)
                    }
                }
            }
            targetFile.absolutePath
        }
    }

    fun deleteDownload(localPath: String?): Boolean {
        if (localPath.isNullOrBlank()) return false
        return runCatching { File(localPath).delete() }.getOrDefault(false)
    }

    fun getTotalDownloadedBytes(): Long {
        return downloadDir.listFiles()?.sumOf { it.length() } ?: 0L
    }

    fun clearAllDownloads(): Boolean {
        return downloadDir.listFiles()?.all { it.delete() } ?: true
    }
}
