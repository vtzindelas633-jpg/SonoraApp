package com.sonora.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sonora.app.data.remote.PodcastShow
import com.sonora.app.domain.model.Track
import com.sonora.app.ui.SonoraViewModel
import com.sonora.app.ui.components.SectionHeader
import com.sonora.app.ui.components.TrackArtwork
import com.sonora.app.ui.components.TrackRowItem
import java.util.Calendar

@Composable
fun HomeScreen(
    viewModel: SonoraViewModel,
    onNavigateToLibrary: () -> Unit,
    onNavigateToAiSocial: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val playback by viewModel.playbackState.collectAsState()
    val localTracks by viewModel.localTracks.collectAsState()
    val favoriteTracks by viewModel.favoriteTracks.collectAsState()
    val trending by viewModel.trendingTracks.collectAsState()
    val genreTracks by viewModel.genreTracks.collectAsState()
    val selectedGenre by viewModel.selectedGenre.collectAsState()
    val podcasts by viewModel.podcasts.collectAsState()
    val episodes by viewModel.selectedPodcastEpisodes.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val isLoading by viewModel.isHomeLoading.collectAsState()

    var activePodcastShow by remember { mutableStateOf<PodcastShow?>(null) }

    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Bom dia"
            in 12..17 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    val genres = listOf("Electronic", "Rock", "Hip-Hop/Rap", "Pop", "Ambient", "Jazz", "Classical")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 140.dp)
    ) {
        // Header with Greeting & Quick Actions
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "$greeting,",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = settings.displayName,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalIconButton(onClick = { viewModel.refreshLocalLibrary(); viewModel.loadOnlineDiscovery() }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Atualizar catálogo")
                    }
                    FilledTonalIconButton(onClick = onNavigateToAiSocial) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = "IA e Retrospectiva", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Quick Access Grid (Favorites, Local, Mix Diário, DJ IA)
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickShortcutCard(
                        title = "Favoritas (${favoriteTracks.size})",
                        icon = Icons.Rounded.Favorite,
                        accent = Color(0xFF00E5A0),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (favoriteTracks.isNotEmpty()) viewModel.playTrackList(favoriteTracks, 0)
                            else onNavigateToLibrary()
                        }
                    )
                    QuickShortcutCard(
                        title = "Locais (${localTracks.size})",
                        icon = Icons.Rounded.Folder,
                        accent = Color(0xFF7C4DFF),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (localTracks.isNotEmpty()) viewModel.playTrackList(localTracks, 0)
                            else onNavigateToLibrary()
                        }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickShortcutCard(
                        title = "Mix Diário",
                        icon = Icons.Rounded.GraphicEq,
                        accent = Color(0xFFFF6D00),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val mix = (favoriteTracks + trending + localTracks).distinctBy { it.id }.shuffled()
                            if (mix.isNotEmpty()) viewModel.playTrackList(mix, 0)
                        }
                    )
                    QuickShortcutCard(
                        title = "DJ com IA",
                        icon = Icons.Rounded.RecordVoiceOver,
                        accent = Color(0xFF00B0FF),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToAiSocial
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (settings.offlineMode) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CloudOff, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Modo Offline ativo — exibindo músicas locais e downloads.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Local Music Quick Carousel
        if (localTracks.isNotEmpty()) {
            item {
                SectionHeader("Suas Músicas Locais", "Reprodução 100% offline do aparelho", "Ver todas", onNavigateToLibrary)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(localTracks.take(12)) { idx, track ->
                        TrackSquareCard(track = track, onClick = { viewModel.playTrackList(localTracks, idx) })
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        // Trending Online (Audius Legal Streaming)
        if (!settings.offlineMode) {
            item {
                SectionHeader("Tendências Musicais", "Streaming legal em alta agora")
                if (isLoading && trending.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(trending.take(15)) { idx, track ->
                            TrackSquareCard(track = track, onClick = { viewModel.playTrackList(trending, idx) })
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // Explore by Genre
            item {
                SectionHeader("Descobertas por Gênero", "Recomendações dinâmicas")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(genres) { genre ->
                        FilterChip(
                            selected = selectedGenre == genre,
                            onClick = { viewModel.selectDiscoveryGenre(genre) },
                            label = { Text(genre) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }

            itemsIndexed(genreTracks.take(8)) { idx, track ->
                TrackRowItem(
                    track = track,
                    isCurrent = playback.currentTrack?.id == track.id,
                    playlists = playlists,
                    onClick = { viewModel.playTrackList(genreTracks, idx) },
                    onFavoriteClick = { viewModel.toggleFavorite(track) },
                    onAddToQueue = { viewModel.playerController.addToQueue(track) },
                    onPlayNext = { viewModel.playerController.playNext(track) },
                    onDownloadClick = { viewModel.downloadTrack(track) },
                    onAddToPlaylist = { plId -> viewModel.addTrackToPlaylist(plId, track) },
                    onShareClick = {
                        context.startActivity(viewModel.shareTextIntent(track.title, "Ouvindo ${track.title} - ${track.artist} no Sonora!"))
                    }
                )
            }

            // Podcasts Section
            if (podcasts.isNotEmpty()) {
                item {
                    SectionHeader("Podcasts", "Toque para abrir e ouvir episódios completos")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(podcasts) { show ->
                            Column(
                                modifier = Modifier
                                    .width(136.dp)
                                    .clickable {
                                        activePodcastShow = show
                                        viewModel.loadPodcastEpisodes(show)
                                    }
                            ) {
                                TrackArtwork(artworkUri = show.artworkUrl, size = 136.dp, cornerRadius = 16.dp)
                                Spacer(Modifier.height(6.dp))
                                Text(show.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(show.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }

    // Podcast Episodes Sheet
    activePodcastShow?.let { show ->
        AlertDialog(
            onDismissRequest = { activePodcastShow = null },
            title = { Text(show.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                if (episodes.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                        itemsIndexed(episodes) { idx, ep ->
                            ListItem(
                                headlineContent = { Text(ep.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                                supportingContent = { Text(ep.artist) },
                                leadingContent = { Icon(Icons.Rounded.PlayCircle, null, tint = MaterialTheme.colorScheme.primary) },
                                modifier = Modifier.clickable {
                                    viewModel.playTrackList(episodes, idx)
                                    activePodcastShow = null
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activePodcastShow = null }) { Text("Fechar") }
            }
        )
    }
}

@Composable
private fun QuickShortcutCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(56.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.22f), Color.Transparent)))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TrackSquareCard(track: Track, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(140.dp)
            .clickable(onClick = onClick)
    ) {
        TrackArtwork(artworkUri = track.artworkUri, size = 140.dp, cornerRadius = 16.dp)
        Spacer(Modifier.height(6.dp))
        Text(
            text = track.title,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = track.artist,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
