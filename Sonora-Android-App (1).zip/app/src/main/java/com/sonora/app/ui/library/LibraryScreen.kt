package com.sonora.app.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sonora.app.data.local.PlaylistEntity
import com.sonora.app.ui.SonoraViewModel
import com.sonora.app.ui.components.TrackRowItem

@Composable
fun LibraryScreen(viewModel: SonoraViewModel) {
    val context = LocalContext.current
    val favorites by viewModel.favoriteTracks.collectAsState()
    val localTracks by viewModel.localTracks.collectAsState()
    val downloads by viewModel.downloadedTracks.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val history by viewModel.recentHistory.collectAsState()
    val playback by viewModel.playbackState.collectAsState()

    val tabs = listOf("Playlists", "Favoritas", "Locais", "Downloads", "Histórico")
    var selectedTab by remember { mutableStateOf("Playlists") }
    var filterQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var openedPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Sua Biblioteca", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalIconButton(onClick = { viewModel.refreshLocalLibrary() }) {
                    Icon(Icons.Rounded.Sync, "Escanear músicas locais")
                }
                FilledIconButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Rounded.Add, "Criar playlist")
                }
            }
        }

        OutlinedTextField(
            value = filterQuery,
            onValueChange = { filterQuery = it },
            placeholder = { Text("Filtrar na biblioteca...") },
            leadingIcon = { Icon(Icons.Rounded.FilterList, null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabs) { tab ->
                FilterChip(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab; openedPlaylist = null },
                    label = { Text(tab) }
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        if (openedPlaylist != null) {
            val pl = openedPlaylist!!
            val plTracks by viewModel.observePlaylistTracks(pl.id).collectAsState(initial = emptyList())
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { openedPlaylist = null }) {
                        Icon(Icons.Rounded.ArrowBack, "Voltar")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(pl.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("${plTracks.size} faixas • Pasta: ${pl.folderName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (plTracks.isNotEmpty()) {
                        FilledIconButton(onClick = { viewModel.playTrackList(plTracks, 0) }) {
                            Icon(Icons.Rounded.PlayArrow, "Tocar playlist")
                        }
                    }
                    IconButton(onClick = {
                        viewModel.deletePlaylist(pl.id)
                        openedPlaylist = null
                    }) {
                        Icon(Icons.Rounded.DeleteOutline, "Excluir playlist")
                    }
                }
                LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
                    itemsIndexed(plTracks) { idx, track ->
                        TrackRowItem(
                            track = track,
                            isCurrent = playback.currentTrack?.id == track.id,
                            playlists = playlists,
                            onClick = { viewModel.playTrackList(plTracks, idx) },
                            onFavoriteClick = { viewModel.toggleFavorite(track) },
                            onAddToQueue = { viewModel.playerController.addToQueue(track) },
                            onPlayNext = { viewModel.playerController.playNext(track) },
                            onDownloadClick = { viewModel.downloadTrack(track) },
                            onAddToPlaylist = { id -> viewModel.addTrackToPlaylist(id, track) },
                            onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 140.dp)
            ) {
                when (selectedTab) {
                    "Playlists" -> {
                        val filtered = playlists.filter { it.name.contains(filterQuery, ignoreCase = true) }
                        if (filtered.isEmpty()) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("Nenhuma playlist ainda. Toque no '+' acima para criar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        } else {
                            items(filtered) { pl ->
                                ListItem(
                                    headlineContent = { Text(pl.name, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = {
                                        val tags = buildList {
                                            add(pl.folderName)
                                            if (pl.isPublic) add("Pública") else add("Privada")
                                            if (pl.isCollaborative) add("Colaborativa")
                                            if (pl.isSmart) add("IA")
                                        }.joinToString(" • ")
                                        Text(tags)
                                    },
                                    leadingContent = {
                                        Icon(
                                            if (pl.isSmart) Icons.Rounded.AutoAwesome else Icons.Rounded.QueueMusic,
                                            null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    trailingContent = { Icon(Icons.Rounded.ChevronRight, null) },
                                    modifier = Modifier.clickable { openedPlaylist = pl }
                                )
                            }
                        }
                    }

                    "Favoritas" -> {
                        val list = favorites.filter { it.title.contains(filterQuery, true) || it.artist.contains(filterQuery, true) }
                        itemsIndexed(list) { idx, track ->
                            TrackRowItem(
                                track = track,
                                isCurrent = playback.currentTrack?.id == track.id,
                                playlists = playlists,
                                onClick = { viewModel.playTrackList(list, idx) },
                                onFavoriteClick = { viewModel.toggleFavorite(track) },
                                onAddToQueue = { viewModel.playerController.addToQueue(track) },
                                onPlayNext = { viewModel.playerController.playNext(track) },
                                onDownloadClick = { viewModel.downloadTrack(track) },
                                onAddToPlaylist = { id -> viewModel.addTrackToPlaylist(id, track) },
                                onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                            )
                        }
                    }

                    "Locais" -> {
                        val list = localTracks.filter { it.title.contains(filterQuery, true) || it.artist.contains(filterQuery, true) }
                        if (list.isEmpty()) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("Nenhuma música local encontrada. Verifique a permissão de áudio e toque no ícone de sincronizar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        } else {
                            itemsIndexed(list) { idx, track ->
                                TrackRowItem(
                                    track = track,
                                    isCurrent = playback.currentTrack?.id == track.id,
                                    playlists = playlists,
                                    onClick = { viewModel.playTrackList(list, idx) },
                                    onFavoriteClick = { viewModel.toggleFavorite(track) },
                                    onAddToQueue = { viewModel.playerController.addToQueue(track) },
                                    onPlayNext = { viewModel.playerController.playNext(track) },
                                    onDownloadClick = { viewModel.downloadTrack(track) },
                                    onAddToPlaylist = { id -> viewModel.addTrackToPlaylist(id, track) },
                                    onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                                )
                            }
                        }
                    }

                    "Downloads" -> {
                        val list = downloads.filter { it.title.contains(filterQuery, true) }
                        itemsIndexed(list) { idx, track ->
                            TrackRowItem(
                                track = track,
                                isCurrent = playback.currentTrack?.id == track.id,
                                playlists = playlists,
                                onClick = { viewModel.playTrackList(list, idx) },
                                onFavoriteClick = { viewModel.toggleFavorite(track) },
                                onAddToQueue = { viewModel.playerController.addToQueue(track) },
                                onPlayNext = { viewModel.playerController.playNext(track) },
                                onDownloadClick = {},
                                onAddToPlaylist = { id -> viewModel.addTrackToPlaylist(id, track) },
                                onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                            )
                        }
                    }

                    "Histórico" -> {
                        items(history) { item ->
                            ListItem(
                                headlineContent = { Text(item.trackTitle) },
                                supportingContent = { Text("${item.artistName} • ${item.genre}") },
                                leadingContent = { Icon(Icons.Rounded.History, null) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var folder by remember { mutableStateOf("Geral") }
        var isPublic by remember { mutableStateOf(false) }
        var isCollab by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Nova Playlist") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Descrição") }, singleLine = true)
                    OutlinedTextField(value = folder, onValueChange = { folder = it }, label = { Text("Pasta") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPublic, onCheckedChange = { isPublic = it })
                        Text("Playlist Pública")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isCollab, onCheckedChange = { isCollab = it })
                        Text("Colaborativa")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.createPlaylist(name, desc, folder, isPublic, isCollab)
                    showCreateDialog = false
                }) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") }
            }
        )
    }
}
