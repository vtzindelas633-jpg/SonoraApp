package com.sonora.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.sonora.app.core.theme.SonoraTheme
import com.sonora.app.ui.SonoraViewModel
import com.sonora.app.ui.components.TrackArtwork
import com.sonora.app.ui.home.HomeScreen
import com.sonora.app.ui.library.LibraryScreen
import com.sonora.app.ui.player.FullPlayerScreen
import com.sonora.app.ui.search.SearchScreen
import com.sonora.app.ui.settings.SettingsScreen
import com.sonora.app.ui.social.AiAndSocialScreen

private sealed class SonoraTab(val route: String, val label: String, val icon: ImageVector) {
    data object Home : SonoraTab("home", "Início", Icons.Rounded.Home)
    data object Search : SonoraTab("search", "Buscar", Icons.Rounded.Search)
    data object Library : SonoraTab("library", "Biblioteca", Icons.Rounded.LibraryMusic)
    data object AiSocial : SonoraTab("ai_social", "IA & Jam", Icons.Rounded.AutoAwesome)
    data object Settings : SonoraTab("settings", "Ajustes", Icons.Rounded.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SonoraViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshLocalLibrary()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestAudioPermissions()

        setContent {
            val settings by viewModel.settings.collectAsState()
            val playback by viewModel.playbackState.collectAsState()
            val toast by viewModel.toastMessage.collectAsState()
            val snackbarHostState = remember { SnackbarHostState() }
            var showFullPlayer by remember { mutableStateOf(false) }

            LaunchedEffect(toast) {
                if (toast != null) {
                    snackbarHostState.showSnackbar(toast!!)
                    viewModel.consumeToast()
                }
            }

            SonoraTheme(darkTheme = settings.darkTheme) {
                val navController = rememberNavController()
                val tabs = listOf(SonoraTab.Home, SonoraTab.Search, SonoraTab.Library, SonoraTab.AiSocial, SonoraTab.Settings)
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = {
                            Column {
                                AnimatedVisibility(
                                    visible = playback.currentTrack != null,
                                    enter = slideInVertically { it } + fadeIn(),
                                    exit = slideOutVertically { it } + fadeOut()
                                ) {
                                    playback.currentTrack?.let { track ->
                                        val progress = if (playback.durationMs > 0) {
                                            (playback.positionMs.toFloat() / playback.durationMs.toFloat()).coerceIn(0f, 1f)
                                        } else 0f

                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { showFullPlayer = true },
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Column {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    TrackArtwork(track.artworkUri, size = 44.dp, cornerRadius = 8.dp)
                                                    Spacer(Modifier.width(10.dp))
                                                    Column(Modifier.weight(1f)) {
                                                        Text(
                                                            track.title,
                                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Text(
                                                            track.artist,
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                    IconButton(onClick = { viewModel.playerController.togglePlayPause() }) {
                                                        Icon(
                                                            if (playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                                            "Play/Pause"
                                                        )
                                                    }
                                                    IconButton(onClick = { viewModel.playerController.skipNext() }) {
                                                        Icon(Icons.Rounded.SkipNext, "Próxima")
                                                    }
                                                }
                                                LinearProgressIndicator(
                                                    progress = { progress },
                                                    modifier = Modifier.fillMaxWidth().height(2.dp),
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }

                                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                                    tabs.forEach { tab ->
                                        val selected = currentRoute == tab.route
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = {
                                                navController.navigate(tab.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(tab.icon, tab.label) },
                                            label = { Text(tab.label, maxLines = 1) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = SonoraTab.Home.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(SonoraTab.Home.route) {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToLibrary = { navController.navigate(SonoraTab.Library.route) },
                                    onNavigateToAiSocial = { navController.navigate(SonoraTab.AiSocial.route) }
                                )
                            }
                            composable(SonoraTab.Search.route) { SearchScreen(viewModel) }
                            composable(SonoraTab.Library.route) { LibraryScreen(viewModel) }
                            composable(SonoraTab.AiSocial.route) { AiAndSocialScreen(viewModel) }
                            composable(SonoraTab.Settings.route) { SettingsScreen(viewModel) }
                        }
                    }

                    AnimatedVisibility(
                        visible = showFullPlayer && playback.currentTrack != null,
                        enter = slideInVertically { it } + fadeIn(),
                        exit = slideOutVertically { it } + fadeOut()
                    ) {
                        FullPlayerScreen(
                            viewModel = viewModel,
                            onCollapse = { showFullPlayer = false }
                        )
                    }
                }
            }
        }
    }

    private fun requestAudioPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }
}
