package com.sonora.app.core.theme

import android.graphics.Bitmap
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val SonoraMint = Color(0xFF00E5A0)
val SonoraViolet = Color(0xFF7C4DFF)
val ObsidianBg = Color(0xFF0A0A0F)
val ObsidianSurface = Color(0xFF14141C)
val ObsidianCard = Color(0xFF1E1E2A)

private val SonoraDarkScheme = darkColorScheme(
    primary = SonoraMint,
    onPrimary = Color(0xFF002114),
    secondary = SonoraViolet,
    onSecondary = Color.White,
    background = ObsidianBg,
    onBackground = Color(0xFFF4F4F8),
    surface = ObsidianSurface,
    onSurface = Color(0xFFF4F4F8),
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = Color(0xFFA0A0B2),
    outline = Color(0xFF2D2D3D)
)

private val SonoraLightScheme = lightColorScheme(
    primary = Color(0xFF009E6D),
    onPrimary = Color.White,
    secondary = SonoraViolet,
    onSecondary = Color.White,
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF111118),
    surface = Color.White,
    onSurface = Color(0xFF111118),
    surfaceVariant = Color(0xFFECEEF4),
    onSurfaceVariant = Color(0xFF5A5A6E),
    outline = Color(0xFFD5D8E2)
)

@Composable
fun SonoraTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) SonoraDarkScheme else SonoraLightScheme,
        content = content
    )
}

suspend fun extractDominantColor(bitmap: Bitmap, fallback: Color = ObsidianCard): Color =
    withContext(Dispatchers.Default) {
        val palette = Palette.from(bitmap).generate()
        val rgb = palette.getDarkVibrantColor(
            palette.getDarkMutedColor(
                palette.getDominantColor(0xFF1E1E2A.toInt())
            )
        )
        Color(rgb)
    }

fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60
    val sec = totalSec % 60
    return "%d:%02d".format(min, sec)
}
