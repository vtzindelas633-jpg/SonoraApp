package com.sonora.app.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sonora.app.SonoraApplication
import com.sonora.app.core.audio.AudioFxController
import com.sonora.app.core.audio.PlaybackUiState
import com.sonora.app.core.audio.SonoraPlayerController
import com.sonora.app.data.local.*
import com.sonora.app.data.remote.AiPlaylistSuggestion
import com.sonora.app.data.remote.LyricsResult
import com.sonora.app.data.remote.PodcastShow
import com.sonora.app.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class SearchUiState(
    val query: String = "",
    val isLoading: Boolean = false,
    val localResults: List<Track> = emptyList(),
    val onlineResults: List<Track> = emptyList(),
    val podcastResults: List<PodcastShow> = emptyList(),
    val lyricMatches: List<Pair<String, String>> = emptyList(),
    val activeFilter: String = "Tudo"
)

class SonoraViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SonoraApplication
    private val dao = app.database.sonoraDao()
    private val settingsRepo = app.settingsRepository

    val playerController = SonoraPlayerController(
        context = application,
        onTrackStarted = { track -> recordTrackPlay(track) }
    )

    val playbackState: StateFlow<PlaybackUiState> = playerController.state

    val settings: StateFlow<UserSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

    val allSavedTracks: StateFlow<List<Track>> = dao.observeAllTracks()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val localTracks: StateFlow<List<Track>> = dao.observeLocalTracks()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val favoriteTracks: StateFlow<List<Track>> = dao.observeFavoriteTracks()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val downloadedTracks: StateFlow<List<Track>> = dao.observeDownloadedTracks()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val playlists: StateFlow<List<PlaylistEntity>> = dao.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val recentHistory: StateFlow<List<PlayHistoryEntity>> = dao.observeRecentHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val searchHistory: StateFlow<List<String>> = dao.observeSearchHistory()
        .map { list -> list.map { it.query } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _trendingTracks = MutableStateFlow<List<Track>>(emptyList())
    val trendingTracks: StateFlow<List<Track>> = _trendingTracks.asStateFlow()

    private val _genreTracks = MutableStateFlow<List<Track>>(emptyList())
    val genreTracks: StateFlow<List<Track>> = _genreTracks.asStateFlow()

    private val _selectedGenre = MutableStateFlow("Electronic")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    private val _podcasts = MutableStateFlow<List<PodcastShow>>(emptyList())
    val podcasts: StateFlow<List<PodcastShow>> = _podcasts.asStateFlow()

    private val _selectedPodcastEpisodes = MutableStateFlow<List<Track>>(emptyList())
    val selectedPodcastEpisodes: StateFlow<List<Track>> = _selectedPodcastEpisodes.asStateFlow()

    private val _isHomeLoading = MutableStateFlow(false)
    val isHomeLoading: StateFlow<Boolean> = _isHomeLoading.asStateFlow()

    private val _lyricsState = MutableStateFlow(LyricsResult())
    val lyricsState: StateFlow<LyricsResult> = _lyricsState.asStateFlow()

    private val _isLyricsLoading = MutableStateFlow(false)
    val isLyricsLoading: StateFlow<Boolean> = _isLyricsLoading.asStateFlow()

    private val _searchState = MutableStateFlow(SearchUiState())
    val searchState: StateFlow<SearchUiState> = _searchState.asStateFlow()

    private val _aiSuggestion = MutableStateFlow<AiPlaylistSuggestion?>(null)
    val aiSuggestion: StateFlow<AiPlaylistSuggestion?> = _aiSuggestion.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _stats = MutableStateFlow(ListeningStats())
    val stats: StateFlow<ListeningStats> = _stats.asStateFlow()

    private val _jamState = MutableStateFlow(JamSessionState())
    val jamState: StateFlow<JamSessionState> = _jamState.asStateFlow()

    private val _downloadedBytes = MutableStateFlow(0L)
    val downloadedBytes: StateFlow<Long> = _downloadedBytes.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        refreshLocalLibrary()
        loadOnlineDiscovery()
        refreshStats()
        refreshStorageInfo()

        // React to settings changes
        viewModelScope.launch {
            settings.collect { s ->
                playerController.setCrossfadeSeconds(s.crossfadeSeconds)
                AudioFxController.setNormalization(s.normalizeVolume)
            }
        }

        // Automatically load synced lyrics whenever current track changes
        viewModelScope.launch {
            playbackState.map { it.currentTrack?.id }.distinctUntilChanged().collect {
                val track = playbackState.value.currentTrack
                if (track != null) loadLyricsForTrack(track)
            }
        }
    }

    fun consumeToast() { _toastMessage.value = null }
    private fun showToast(msg: String) { _toastMessage.value = msg }

    fun refreshLocalLibrary() {
        viewModelScope.launch {
            val scanned = app.localScanner.scanDeviceAudio()
            if (scanned.isNotEmpty()) {
                dao.insertTracksIgnore(scanned.map { it.toEntity() })
            }
        }
    }

    fun loadOnlineDiscovery() {
        viewModelScope.launch {
            if (settings.value.offlineMode) return@launch
            _isHomeLoading.value = true
            val trending = app.audiusApi.getTrendingTracks(limit = 20)
            if (trending.isNotEmpty()) {
                _trendingTracks.value = trending
                dao.insertTracksIgnore(trending.map { it.toEntity() })
            }
            val genreList = app.audiusApi.getTrendingTracks(genre = _selectedGenre.value, limit = 15)
            _genreTracks.value = genreList
            val pods = app.podcastApi.searchPodcasts("música tecnologia brasil", limit = 10)
            _podcasts.value = pods
            _isHomeLoading.value = false
        }
    }

    fun selectDiscoveryGenre(genre: String) {
        _selectedGenre.value = genre
        viewModelScope.launch {
            if (settings.value.offlineMode) return@launch
            _genreTracks.value = app.audiusApi.getTrendingTracks(genre = genre, limit = 15)
        }
    }

    fun loadPodcastEpisodes(show: PodcastShow) {
        viewModelScope.launch {
            _selectedPodcastEpisodes.value = emptyList()
            val eps = app.podcastApi.fetchEpisodes(show)
            _selectedPodcastEpisodes.value = eps
            if (eps.isNotEmpty()) dao.insertTracksIgnore(eps.map { it.toEntity() })
        }
    }

    fun playTrackList(tracks: List<Track>, index: Int = 0) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            dao.insertTracksIgnore(tracks.map { it.toEntity() })
        }
        playerController.playQueue(tracks, index)
    }

    private fun recordTrackPlay(track: Track) {
        viewModelScope.launch {
            dao.insertTracksIgnore(listOf(track.toEntity()))
            dao.incrementPlayCount(track.id)
            dao.insertHistory(
                PlayHistoryEntity(
                    trackId = track.id,
                    trackTitle = track.title,
                    artistName = track.artist,
                    albumName = track.album,
                    genre = track.genre,
                    playedMs = track.durationMs.coerceAtLeast(30_000L)
                )
            )
            refreshStats()
        }
    }

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val existing = dao.getTrackById(track.id)
            val newState = !(existing?.isFavorite ?: track.isFavorite)
            if (existing == null) {
                dao.upsertTrack(track.copy(isFavorite = newState).toEntity())
            } else {
                dao.setFavorite(track.id, newState)
            }
            showToast(if (newState) "Adicionada aos Favoritos" else "Removida dos Favoritos")
        }
    }

    fun downloadTrack(track: Track) {
        if (track.source == TrackSource.LOCAL) {
            showToast("Arquivo já está armazenado localmente.")
            return
        }
        viewModelScope.launch {
            showToast("Baixando ${track.title}...")
            val result = app.downloadManager.downloadTrack(track, settings.value.wifiOnlyDownloads)
            result.onSuccess { path ->
                dao.upsertTrack(track.copy(isDownloaded = true, localPath = path).toEntity())
                refreshStorageInfo()
                showToast("Download concluído: ${track.title}")
            }.onFailure { err ->
                showToast(err.message ?: "Erro ao baixar faixa.")
            }
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            app.downloadManager.clearAllDownloads()
            downloadedTracks.value.filter { it.source != TrackSource.LOCAL }.forEach {
                dao.setDownloadState(it.id, false, null)
            }
            refreshStorageInfo()
            showToast("Downloads removidos com sucesso.")
        }
    }

    private fun refreshStorageInfo() {
        _downloadedBytes.value = app.downloadManager.getTotalDownloadedBytes()
    }

    // Playlists
    fun createPlaylist(name: String, description: String = "", folder: String = "Geral", isPublic: Boolean = false, isCollaborative: Boolean = false) {
        if (name.isBlank()) return
        viewModelScope.launch {
            dao.insertPlaylist(
                PlaylistEntity(
                    name = name.trim(),
                    description = description.trim(),
                    folderName = folder,
                    isPublic = isPublic,
                    isCollaborative = isCollaborative
                )
            )
            showToast("Playlist '$name' criada!")
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String, newDesc: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            dao.updatePlaylist(playlistId, newName.trim(), newDesc.trim())
            showToast("Playlist atualizada.")
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            dao.deletePlaylist(playlistId)
            showToast("Playlist excluída.")
        }
    }

    fun addTrackToPlaylist(playlistId: Long, track: Track) {
        viewModelScope.launch {
            dao.insertTracksIgnore(listOf(track.toEntity()))
            val pos = dao.getPlaylistTrackCount(playlistId)
            dao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId = playlistId, trackId = track.id, position = pos))
            showToast("Adicionada à playlist!")
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            dao.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun observePlaylistTracks(playlistId: Long): Flow<List<Track>> {
        return dao.observeTracksForPlaylist(playlistId).map { list -> list.map { it.toDomain() } }
    }

    // Global Search
    fun updateSearchQuery(query: String) {
        _searchState.update { it.copy(query = query) }
    }

    fun setSearchFilter(filter: String) {
        _searchState.update { it.copy(activeFilter = filter) }
    }

    fun executeSearch(query: String = _searchState.value.query) {
        val clean = query.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            _searchState.update { it.copy(query = clean, isLoading = true) }
            dao.saveSearchQuery(SearchHistoryEntity(clean))

            val local = dao.searchTracks(clean).map { it.toDomain() }
            val online = if (!settings.value.offlineMode) app.audiusApi.searchTracks(clean, 20) else emptyList()
            val pods = if (!settings.value.offlineMode) app.podcastApi.searchPodcasts(clean, 8) else emptyList()
            val lyrics = if (!settings.value.offlineMode) app.lyricsApi.searchSongsByLyricSnippet(clean) else emptyList()

            _searchState.update {
                it.copy(
                    isLoading = false,
                    localResults = local,
                    onlineResults = online,
                    podcastResults = pods,
                    lyricMatches = lyrics
                )
            }
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch { dao.clearSearchHistory() }
    }

    // Lyrics
    private fun loadLyricsForTrack(track: Track) {
        if (settings.value.offlineMode || track.source == TrackSource.PODCAST) {
            _lyricsState.value = LyricsResult()
            return
        }
        viewModelScope.launch {
            _isLyricsLoading.value = true
            _lyricsState.value = app.lyricsApi.getLyrics(track.artist, track.title)
            _isLyricsLoading.value = false
        }
    }

    // Music AI
    fun generateAiPlaylist(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _isAiLoading.value = true
            val pool = (allSavedTracks.value + _trendingTracks.value).distinctBy { it.id }
            val result = app.aiEngine.generatePlaylist(prompt, pool, settings.value.geminiApiKey)
            _aiSuggestion.value = result
            _isAiLoading.value = false
        }
    }

    fun saveAiSuggestionAsPlaylist() {
        val suggestion = _aiSuggestion.value ?: return
        if (suggestion.tracks.isEmpty()) return
        viewModelScope.launch {
            val id = dao.insertPlaylist(
                PlaylistEntity(
                    name = suggestion.playlistName,
                    description = suggestion.explanation,
                    folderName = "IA Sonora",
                    isSmart = true
                )
            )
            suggestion.tracks.forEachIndexed { idx, track ->
                dao.insertTracksIgnore(listOf(track.toEntity()))
                dao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId = id, trackId = track.id, position = idx))
            }
            showToast("Playlist IA salva na sua Biblioteca!")
        }
    }

    // Statistics & Retrospective
    fun refreshStats() {
        viewModelScope.launch {
            val history = dao.getAllHistory()
            val allTracksMap = allSavedTracks.value.associateBy { it.id }
            val totalPlays = history.size
            val totalMs = history.sumOf { it.playedMs }

            val topArtists = history.groupingBy { it.artistName }.eachCount()
                .entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }

            val topGenres = history.groupingBy { it.genre }.eachCount()
                .entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }

            val favAlbum = history.groupingBy { it.albumName }.eachCount()
                .maxByOrNull { it.value }?.key ?: "Nenhum ainda"

            val topTracks = history.groupingBy { it.trackId }.eachCount()
                .entries.sortedByDescending { it.value }.take(10)
                .mapNotNull { (id, count) ->
                    val t = allTracksMap[id] ?: history.firstOrNull { it.trackId == id }?.let { h ->
                        Track(id = h.trackId, title = h.trackTitle, artist = h.artistName, album = h.albumName, genre = h.genre, durationMs = h.playedMs, mediaUri = "")
                    }
                    t?.let { it to count }
                }

            _stats.value = ListeningStats(
                totalPlays = totalPlays,
                totalListeningMs = totalMs,
                topArtists = topArtists,
                topTracks = topTracks,
                topGenres = topGenres,
                favoriteAlbum = favAlbum
            )
        }
    }

    // Jam Session
    fun startJamSession() {
        val code = UUID.randomUUID().toString().take(6).uppercase()
        _jamState.value = JamSessionState(
            isActive = true,
            joinCode = code,
            hostName = settings.value.displayName,
            participants = listOf("${settings.value.displayName} (Anfitrião)"),
            allowGuestQueue = true
        )
        showToast("Sessão Jam criada! Código: $code")
    }

    fun joinJamSession(code: String) {
        val clean = code.trim().uppercase()
        if (clean.length < 4) {
            showToast("Digite um código válido.")
            return
        }
        _jamState.value = JamSessionState(
            isActive = true,
            joinCode = clean,
            hostName = "Sessão $clean",
            participants = listOf("Anfitrião", "${settings.value.displayName} (Você)"),
            allowGuestQueue = true
        )
        showToast("Conectado à sessão Jam $clean")
    }

    fun leaveJamSession() {
        _jamState.value = JamSessionState()
        showToast("Você saiu da sessão Jam.")
    }

    fun shareTextIntent(subject: String, text: String): Intent {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        return Intent.createChooser(sendIntent, "Compartilhar via Sonora")
    }

    // Settings updates
    fun setDarkTheme(v: Boolean) = viewModelScope.launch { settingsRepo.setDarkTheme(v) }
    fun setDisplayName(v: String) = viewModelScope.launch { settingsRepo.setDisplayName(v) }
    fun setAudioQuality(v: String) = viewModelScope.launch { settingsRepo.setAudioQuality(v) }
    fun setCrossfade(v: Int) = viewModelScope.launch { settingsRepo.setCrossfade(v) }
    fun setNormalizeVolume(v: Boolean) = viewModelScope.launch { settingsRepo.setNormalizeVolume(v) }
    fun setWifiOnlyDownloads(v: Boolean) = viewModelScope.launch { settingsRepo.setWifiOnlyDownloads(v) }
    fun setOfflineMode(v: Boolean) = viewModelScope.launch { settingsRepo.setOfflineMode(v) }
    fun setGeminiApiKey(v: String) = viewModelScope.launch { settingsRepo.setGeminiApiKey(v) }
    fun setSupabaseUrl(v: String) = viewModelScope.launch { settingsRepo.setSupabaseUrl(v) }

    override fun onCleared() {
        super.onCleared()
        playerController.release()
    }
}
