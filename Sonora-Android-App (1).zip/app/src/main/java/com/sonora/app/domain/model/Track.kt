package com.sonora.app.domain.model

enum class TrackSource {
    LOCAL, AUDIUS, PODCAST, DOWNLOADED
}

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String = "Desconhecido",
    val durationMs: Long,
    val artworkUri: String? = null,
    val mediaUri: String,
    val source: TrackSource = TrackSource.LOCAL,
    val year: Int = 0,
    val isFavorite: Boolean = false,
    val isDownloaded: Boolean = false,
    val localPath: String? = null,
    val playCount: Int = 0
)

data class LyricLine(
    val timestampMs: Long,
    val text: String
)

data class PlaylistModel(
    val id: Long = 0,
    val name: String,
    val description: String = "",
    val folderName: String = "Geral",
    val isPublic: Boolean = false,
    val isCollaborative: Boolean = false,
    val isSmart: Boolean = false,
    val smartRule: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val trackCount: Int = 0
)

data class ListeningStats(
    val totalPlays: Int = 0,
    val totalListeningMs: Long = 0L,
    val topArtists: List<Pair<String, Int>> = emptyList(),
    val topTracks: List<Pair<Track, Int>> = emptyList(),
    val topGenres: List<Pair<String, Int>> = emptyList(),
    val favoriteAlbum: String = "Nenhum ainda"
)

data class JamSessionState(
    val isActive: Boolean = false,
    val joinCode: String = "",
    val hostName: String = "Você",
    val participants: List<String> = emptyList(),
    val allowGuestQueue: Boolean = true
)
