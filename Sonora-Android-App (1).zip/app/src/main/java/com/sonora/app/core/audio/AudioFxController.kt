package com.sonora.app.core.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqBandState(
    val index: Short,
    val centerFreqHz: Int,
    val levelMb: Short,
    val minMb: Short,
    val maxMb: Short
)

object AudioFxController {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    private val _bands = MutableStateFlow<List<EqBandState>>(emptyList())
    val bands: StateFlow<List<EqBandState>> = _bands.asStateFlow()

    private val _activePreset = MutableStateFlow("Flat")
    val activePreset: StateFlow<String> = _activePreset.asStateFlow()

    private val _bassStrength = MutableStateFlow(0)
    val bassStrength: StateFlow<Int> = _bassStrength.asStateFlow()

    val customPresets: Map<String, List<Int>> = mapOf(
        "Flat" to listOf(0, 0, 0, 0, 0),
        "Rock" to listOf(500, 300, -100, 300, 500),
        "Pop" to listOf(-100, 300, 500, 200, -100),
        "Jazz" to listOf(400, 200, -200, 200, 400),
        "Clássica" to listOf(400, 300, -100, 300, 500),
        "Eletrônica" to listOf(600, 400, 0, 300, 600),
        "Hip-Hop" to listOf(700, 500, 0, 100, 300),
        "Voz" to listOf(-300, 100, 600, 500, -100)
    )

    fun attachToSession(audioSessionId: Int, normalizeEnabled: Boolean) {
        if (audioSessionId == 0) return
        release()
        runCatching {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply {
                enabled = true
                setStrength(_bassStrength.value.toShort())
            }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(if (normalizeEnabled) 250 else 0)
                enabled = normalizeEnabled
            }
            refreshBands()
        }
    }

    fun setBandLevel(bandIndex: Short, levelMb: Short) {
        runCatching {
            equalizer?.setBandLevel(bandIndex, levelMb)
            _activePreset.value = "Personalizado"
            refreshBands()
        }
    }

    fun applyPreset(presetName: String) {
        val values = customPresets[presetName] ?: return
        val eq = equalizer ?: return
        runCatching {
            val count = eq.numberOfBands.toInt()
            val minMb = eq.bandLevelRange[0]
            val maxMb = eq.bandLevelRange[1]
            for (i in 0 until count) {
                val target = values.getOrElse(i) { 0 }.coerceIn(minMb.toInt(), maxMb.toInt()).toShort()
                eq.setBandLevel(i.toShort(), target)
            }
            _activePreset.value = presetName
            refreshBands()
        }
    }

    fun setBassBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        _bassStrength.value = clamped
        runCatching {
            bassBoost?.setStrength(clamped.toShort())
        }
    }

    fun setNormalization(enabled: Boolean) {
        runCatching {
            loudnessEnhancer?.setTargetGain(if (enabled) 250 else 0)
            loudnessEnhancer?.enabled = enabled
        }
    }

    private fun refreshBands() {
        val eq = equalizer ?: return
        val minMb = eq.bandLevelRange[0]
        val maxMb = eq.bandLevelRange[1]
        val list = mutableListOf<EqBandState>()
        for (i in 0 until eq.numberOfBands) {
            val idx = i.toShort()
            list.add(
                EqBandState(
                    index = idx,
                    centerFreqHz = eq.getCenterFreq(idx) / 1000,
                    levelMb = eq.getBandLevel(idx),
                    minMb = minMb,
                    maxMb = maxMb
                )
            )
        }
        _bands.value = list
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        loudnessEnhancer = null
    }
}
