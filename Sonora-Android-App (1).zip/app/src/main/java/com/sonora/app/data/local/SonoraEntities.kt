package com.sonora.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sonora.app.domain.model.Track
import com.sonora.app.domain.model.TrackSource

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val durationMs: Long,
    val artworkUri: String?,
    val mediaUri: String,
    val source: String,
    val year: Int,
    val isFavorite: Boolean = false,
    val isDownloaded: Boolean = false,
    val localPath: String? = null,
    val playCount: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): Track = Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        genre = genre,
        durationMs = durationMs,
        artworkUri = artworkUri,
        mediaUri = if (isDownloaded && !localPath.isNullOrBlank()) localPath else mediaUri,
        source = runCatching { TrackSource.valueOf(source) }.getOrDefault(TrackSource.LOCAL),
        year = year,
        isFavorite = isFavorite,
        isDownloaded = isDownloaded,
        localPath = localPath,
        playCount = playCount
    )
}

fun Track.toEntity(): TrackEntity = TrackEntity(
    id = id,
    title = title,
    artist = artist,
    album = album,
    genre = genre,
    durationMs = durationMs,
    artworkUri = artworkUri,
    mediaUri = mediaUri,
    source = source.name,
    year = year,
    isFavorite = isFavorite,
    isDownloaded = isDownloaded,
    localPath = localPath,
    playCount = playCount
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val folderName: String = "Geral",
    val isPublic: Boolean = false,
    val isCollaborative: Boolean = false,
    val isSmart: Boolean = false,
    val smartRule: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrackCrossRef(
    val playlistId: Long,
    val trackId: String,
    val position: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val trackTitle: String,
    val artistName: String,
    val albumName: String,
    val genre: String,
    val playedMs: Long,
    val skipped: Boolean = false,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)
