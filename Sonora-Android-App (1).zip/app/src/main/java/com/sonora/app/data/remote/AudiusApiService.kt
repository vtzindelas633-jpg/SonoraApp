package com.sonora.app.data.remote

import com.sonora.app.domain.model.Track
import com.sonora.app.domain.model.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class AudiusApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val appName = "SonoraMusicApp"
    private var cachedHost: String = "https://discoveryprovider.audius.co"

    private fun resolveHost(): String {
        return runCatching {
            val req = Request.Builder().url("https://api.audius.co").build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string().orEmpty()
                    val data = JSONObject(body).optJSONArray("data")
                    if (data != null && data.length() > 0) {
                        cachedHost = data.getString(0).trimEnd('/')
                    }
                }
            }
            cachedHost
        }.getOrDefault(cachedHost)
    }

    suspend fun getTrendingTracks(genre: String? = null, limit: Int = 25): List<Track> = withContext(Dispatchers.IO) {
        val host = resolveHost()
        val genreParam = if (!genre.isNullOrBlank()) "&genre=${URLEncoder.encode(genre, "UTF-8")}" else ""
        val url = "$host/v1/tracks/trending?app_name=$appName&limit=$limit$genreParam"
        fetchTrackList(host, url)
    }

    suspend fun searchTracks(query: String, limit: Int = 25): List<Track> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val host = resolveHost()
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val url = "$host/v1/tracks/search?query=$encoded&app_name=$appName&limit=$limit"
        fetchTrackList(host, url)
    }

    private fun fetchTrackList(host: String, url: String): List<Track> {
        return runCatching {
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val json = JSONObject(resp.body?.string().orEmpty())
                val arr = json.optJSONArray("data") ?: return emptyList()
                val result = mutableListOf<Track>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    if (id.isBlank()) continue
                    val title = obj.optString("title", "Sem título")
                    val user = obj.optJSONObject("user")
                    val artist = user?.optString("name", "Artista Independente") ?: "Artista Independente"
                    val genre = obj.optString("genre", "Geral").ifBlank { "Geral" }
                    val durationSec = obj.optLong("duration", 0L)
                    val artworkObj = obj.optJSONObject("artwork")
                    val artworkUrl = artworkObj?.optString("480x480")
                        ?.ifBlank { artworkObj.optString("150x150") }
                    val streamUrl = "$host/v1/tracks/$id/stream?app_name=$appName"
                    result.add(
                        Track(
                            id = "audius_$id",
                            title = title,
                            artist = artist,
                            album = genre,
                            genre = genre,
                            durationMs = durationSec * 1000L,
                            artworkUri = artworkUrl,
                            mediaUri = streamUrl,
                            source = TrackSource.AUDIUS
                        )
                    )
                }
                result
            }
        }.getOrDefault(emptyList())
    }
}
