package com.sonora.app

import android.app.Application
import com.sonora.app.data.local.LocalMusicScanner
import com.sonora.app.data.local.SettingsRepository
import com.sonora.app.data.local.SonoraDatabase
import com.sonora.app.data.remote.*

class SonoraApplication : Application() {

    lateinit var database: SonoraDatabase
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var localScanner: LocalMusicScanner
        private set
    lateinit var audiusApi: AudiusApiService
        private set
    lateinit var lyricsApi: LyricsApiService
        private set
    lateinit var podcastApi: PodcastApiService
        private set
    lateinit var downloadManager: SonoraDownloadManager
        private set
    lateinit var aiEngine: MusicAiEngine
        private set

    override fun onCreate() {
        super.onCreate()
        database = SonoraDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        localScanner = LocalMusicScanner(this)
        audiusApi = AudiusApiService()
        lyricsApi = LyricsApiService()
        podcastApi = PodcastApiService()
        downloadManager = SonoraDownloadManager(this)
        aiEngine = MusicAiEngine()
    }
}
