package com.sonora.app.data.remote

import com.sonora.app.domain.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class LyricsResult(
    val syncedLines: List<LyricLine> = emptyList(),
    val plainLyrics: String = ""
)

class LyricsApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun getLyrics(artist: String, title: String): LyricsResult = withContext(Dispatchers.IO) {
        val cleanTitle = title.replace(Regex("""\(.*?\)|\[.*?]"""), "").trim()
        val encArtist = URLEncoder.encode(artist.trim(), "UTF-8")
        val encTitle = URLEncoder.encode(cleanTitle, "UTF-8")
        val url = "https://lrclib.net/api/get?artist_name=$encArtist&track_name=$encTitle"

        val direct = runCatching {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "SonoraMusicApp/1.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val obj = JSONObject(resp.body?.string().orEmpty())
                parseLyricsJson(obj)
            }
        }.getOrNull()

        if (direct != null && (direct.syncedLines.isNotEmpty() || direct.plainLyrics.isNotBlank())) {
            return@withContext direct
        }

        // Fallback search
        runCatching {
            val searchUrl = "https://lrclib.net/api/search?q=${URLEncoder.encode("$artist $cleanTitle", "UTF-8")}"
            val req = Request.Builder().url(searchUrl).header("User-Agent", "SonoraMusicApp/1.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use LyricsResult()
                val arr = JSONArray(resp.body?.string().orEmpty())
                if (arr.length() > 0) parseLyricsJson(arr.getJSONObject(0)) else LyricsResult()
            }
        }.getOrDefault(LyricsResult())
    }

    suspend fun searchSongsByLyricSnippet(snippet: String): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        if (snippet.isBlank()) return@withContext emptyList()
        runCatching {
            val url = "https://lrclib.net/api/search?q=${URLEncoder.encode(snippet.trim(), "UTF-8")}"
            val req = Request.Builder().url(url).header("User-Agent", "SonoraMusicApp/1.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use emptyList()
                val arr = JSONArray(resp.body?.string().orEmpty())
                val out = mutableListOf<Pair<String, String>>()
                for (i in 0 until minOf(arr.length(), 15)) {
                    val obj = arr.getJSONObject(i)
                    out.add(obj.optString("trackName") to obj.optString("artistName"))
                }
                out
            }
        }.getOrDefault(emptyList())
    }

    private fun parseLyricsJson(obj: JSONObject): LyricsResult {
        val syncedRaw = obj.optString("syncedLyrics", "")
        val plainRaw = obj.optString("plainLyrics", "")
        val parsed = if (syncedRaw.isNotBlank() && syncedRaw != "null") parseLrc(syncedRaw) else emptyList()
        return LyricsResult(
            syncedLines = parsed,
            plainLyrics = if (plainRaw == "null") "" else plainRaw
        )
    }

    private fun parseLrc(lrc: String): List<LyricLine> {
        val regex = Regex("""\[(\d{2}):(\d{2})\.(\d{2,3})](.*)""")
        val lines = mutableListOf<LyricLine>()
        lrc.lines().forEach { line ->
            val match = regex.find(line.trim())
            if (match != null) {
                val min = match.groupValues[1].toLongOrNull() ?: 0L
                val sec = match.groupValues[2].toLongOrNull() ?: 0L
                val fracStr = match.groupValues[3]
                val ms = if (fracStr.length == 2) (fracStr.toLongOrNull() ?: 0L) * 10L else (fracStr.toLongOrNull() ?: 0L)
                val text = match.groupValues[4].trim()
                if (text.isNotEmpty()) {
                    lines.add(LyricLine(timestampMs = (min * 60_000L) + (sec * 1_000L) + ms, text = text))
                }
            }
        }
        return lines.sortedBy { it.timestampMs }
    }
}
