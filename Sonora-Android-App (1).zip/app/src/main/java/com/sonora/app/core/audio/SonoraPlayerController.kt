package com.sonora.app.core.audio

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.sonora.app.domain.model.Track
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

data class PlaybackUiState(
    val currentTrack: Track? = null,
    val queue: List<Track> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val playbackSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val sleepTimerMinutesLeft: Int? = null,
    val djModeEnabled: Boolean = false,
    val errorMessage: String? = null
)

class SonoraPlayerController(
    private val context: Context,
    private val onTrackStarted: (Track) -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controller: MediaController? = null
    private var sleepTimerJob: Job? = null
    private var tts: TextToSpeech? = null
    private var crossfadeSec: Int = 0

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    init {
        connectToService()
        startProgressTicker()
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
            }
        }
    }

    private fun connectToService() {
        val sessionToken = SessionToken(context, ComponentName(context, SonoraMediaService::class.java))
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        future.addListener({
            runCatching {
                val mc = future.get()
                controller = mc
                mc.addListener(playerListener)
                syncFromPlayer(mc)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update { it.copy(isPlaying = isPlaying, errorMessage = null) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _state.update { it.copy(isBuffering = playbackState == Player.STATE_BUFFERING) }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val mc = controller ?: return
            val idx = mc.currentMediaItemIndex
            val q = _state.value.queue
            val track = q.getOrNull(idx)
            _state.update {
                it.copy(
                    currentIndex = idx,
                    currentTrack = track,
                    durationMs = mc.duration.coerceAtLeast(track?.durationMs ?: 0L),
                    errorMessage = null
                )
            }
            if (track != null) {
                onTrackStarted(track)
                if (_state.value.djModeEnabled) {
                    speakDj("Tocando agora ${track.title}, de ${track.artist}.")
                }
            }
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _state.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorMessage = "Falha na reprodução: ${error.localizedMessage ?: "verifique sua conexão"}"
                )
            }
        }
    }

    private fun startProgressTicker() {
        scope.launch {
            while (isActive) {
                val mc = controller
                if (mc != null && mc.isPlaying) {
                    val pos = mc.currentPosition.coerceAtLeast(0L)
                    val dur = mc.duration.coerceAtLeast(_state.value.currentTrack?.durationMs ?: 0L)
                    _state.update { it.copy(positionMs = pos, durationMs = dur) }

                    // Crossfade volume ramp near end of track
                    if (crossfadeSec > 0 && dur > 15_000L) {
                        val remainingMs = dur - pos
                        val fadeWindowMs = crossfadeSec * 1000L
                        if (remainingMs in 1..fadeWindowMs) {
                            val factor = (remainingMs.toFloat() / fadeWindowMs.toFloat()).coerceIn(0.1f, 1f)
                            mc.volume = _state.value.volume * factor
                        } else if (pos < fadeWindowMs) {
                            val factor = (pos.toFloat() / fadeWindowMs.toFloat()).coerceIn(0.2f, 1f)
                            mc.volume = _state.value.volume * factor
                        } else {
                            mc.volume = _state.value.volume
                        }
                    }
                }
                delay(400L)
            }
        }
    }

    private fun syncFromPlayer(mc: MediaController) {
        _state.update {
            it.copy(
                isPlaying = mc.isPlaying,
                shuffleEnabled = mc.shuffleModeEnabled,
                repeatMode = mc.repeatMode,
                volume = mc.volume
            )
        }
    }

    private fun Track.toMediaItem(): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(artworkUri?.let { Uri.parse(it) })
            .build()
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(Uri.parse(mediaUri))
            .setMediaMetadata(metadata)
            .build()
    }

    fun playQueue(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, tracks.lastIndex)
        val mc = controller ?: return
        val items = tracks.map { it.toMediaItem() }
        _state.update {
            it.copy(
                queue = tracks,
                currentIndex = safeIndex,
                currentTrack = tracks[safeIndex],
                positionMs = 0L,
                durationMs = tracks[safeIndex].durationMs,
                errorMessage = null
            )
        }
        mc.setMediaItems(items, safeIndex, 0L)
        mc.prepare()
        mc.play()
        onTrackStarted(tracks[safeIndex])
    }

    fun playTrackAt(index: Int) {
        val mc = controller ?: return
        val q = _state.value.queue
        if (index !in q.indices) return
        mc.seekTo(index, 0L)
        mc.play()
    }

    fun addToQueue(track: Track) {
        val mc = controller ?: return
        if (_state.value.queue.isEmpty()) {
            playQueue(listOf(track), 0)
            return
        }
        mc.addMediaItem(track.toMediaItem())
        _state.update { it.copy(queue = it.queue + track) }
    }

    fun playNext(track: Track) {
        val mc = controller ?: return
        val currentQueue = _state.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playQueue(listOf(track), 0)
            return
        }
        val insertIndex = (mc.currentMediaItemIndex + 1).coerceAtMost(currentQueue.size)
        currentQueue.add(insertIndex, track)
        mc.addMediaItem(insertIndex, track.toMediaItem())
        _state.update { it.copy(queue = currentQueue) }
    }

    fun removeFromQueue(index: Int) {
        val mc = controller ?: return
        val currentQueue = _state.value.queue.toMutableList()
        if (index !in currentQueue.indices) return
        currentQueue.removeAt(index)
        mc.removeMediaItem(index)
        _state.update {
            it.copy(
                queue = currentQueue,
                currentIndex = mc.currentMediaItemIndex,
                currentTrack = currentQueue.getOrNull(mc.currentMediaItemIndex)
            )
        }
    }

    fun clearQueue() {
        controller?.clearMediaItems()
        _state.update { it.copy(queue = emptyList(), currentIndex = -1, currentTrack = null, isPlaying = false) }
    }

    fun togglePlayPause() {
        val mc = controller ?: return
        if (mc.isPlaying) mc.pause() else mc.play()
    }

    fun skipNext() {
        val mc = controller ?: return
        if (mc.hasNextMediaItem()) mc.seekToNextMediaItem()
    }

    fun skipPrevious() {
        val mc = controller ?: return
        if (mc.currentPosition > 3000L) mc.seekTo(0L)
        else if (mc.hasPreviousMediaItem()) mc.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs.coerceAtLeast(0L))
        _state.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    fun seekRelative(deltaMs: Long) {
        val target = (_state.value.positionMs + deltaMs).coerceIn(0L, _state.value.durationMs.coerceAtLeast(1L))
        seekTo(target)
    }

    fun toggleShuffle() {
        val mc = controller ?: return
        val next = !mc.shuffleModeEnabled
        mc.shuffleModeEnabled = next
        _state.update { it.copy(shuffleEnabled = next) }
    }

    fun cycleRepeatMode() {
        val mc = controller ?: return
        val next = when (mc.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        mc.repeatMode = next
        _state.update { it.copy(repeatMode = next) }
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        controller?.playbackParameters = PlaybackParameters(clamped)
        _state.update { it.copy(playbackSpeed = clamped) }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        controller?.volume = clamped
        _state.update { it.copy(volume = clamped) }
    }

    fun setCrossfadeSeconds(seconds: Int) {
        crossfadeSec = seconds.coerceIn(0, 12)
    }

    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null || minutes <= 0) {
            _state.update { it.copy(sleepTimerMinutesLeft = null) }
            return
        }
        _state.update { it.copy(sleepTimerMinutesLeft = minutes) }
        sleepTimerJob = scope.launch {
            var left = minutes
            while (left > 0) {
                delay(60_000L)
                left--
                _state.update { it.copy(sleepTimerMinutesLeft = if (left > 0) left else null) }
            }
            controller?.pause()
        }
    }

    fun setDjMode(enabled: Boolean) {
        _state.update { it.copy(djModeEnabled = enabled) }
        if (enabled) {
            speakDj("DJ Sonora ativado. Preparando a próxima sequência para você.")
        }
    }

    fun speakDj(text: String) {
        runCatching {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonora_dj_${System.currentTimeMillis()}")
        }
    }

    fun release() {
        sleepTimerJob?.cancel()
        scope.cancel()
        tts?.shutdown()
        controller?.release()
    }
}
