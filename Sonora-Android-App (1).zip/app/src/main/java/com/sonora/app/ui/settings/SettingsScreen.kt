package com.sonora.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sonora.app.ui.SonoraViewModel

@Composable
fun SettingsScreen(viewModel: SonoraViewModel) {
    val settings by viewModel.settings.collectAsState()
    val downloadedBytes by viewModel.downloadedBytes.collectAsState()

    var displayName by remember(settings.displayName) { mutableStateOf(settings.displayName) }
    var geminiKey by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var supabaseUrl by remember(settings.supabaseUrl) { mutableStateOf(settings.supabaseUrl) }

    val qualities = listOf("Econômica (96 kbps)", "Normal (160 kbps)", "Alta (320 kbps)", "Lossless (FLAC)")
    val mbUsed = "%.2f MB".format(downloadedBytes / (1024.0 * 1024.0))

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Configurações", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
        }

        // Perfil & Aparência
        item {
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Perfil e Aparência", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it; viewModel.setDisplayName(it) },
                        label = { Text("Nome de exibição") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tema Escuro (Obsidian)")
                        Switch(checked = settings.darkTheme, onCheckedChange = { viewModel.setDarkTheme(it) })
                    }
                }
            }
        }

        // Áudio e Reprodução
        item {
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Qualidade de Áudio e Reprodução", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        qualities.take(2).forEach { q ->
                            FilterChip(selected = settings.audioQuality == q, onClick = { viewModel.setAudioQuality(q) }, label = { Text(q.substringBefore(" ")) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        qualities.drop(2).forEach { q ->
                            FilterChip(selected = settings.audioQuality == q, onClick = { viewModel.setAudioQuality(q) }, label = { Text(q.substringBefore(" ")) })
                        }
                    }
                    Text("Crossfade: ${settings.crossfadeSeconds}s", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = settings.crossfadeSeconds.toFloat(),
                        onValueChange = { viewModel.setCrossfade(it.toInt()) },
                        valueRange = 0f..12f,
                        steps = 11
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Normalização de volume")
                        Switch(checked = settings.normalizeVolume, onCheckedChange = { viewModel.setNormalizeVolume(it) })
                    }
                }
            }
        }

        // Offline e Armazenamento
        item {
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Downloads e Armazenamento", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Modo Offline")
                        Switch(checked = settings.offlineMode, onCheckedChange = { viewModel.setOfflineMode(it) })
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Baixar somente por Wi-Fi")
                        Switch(checked = settings.wifiOnlyDownloads, onCheckedChange = { viewModel.setWifiOnlyDownloads(it) })
                    }
                    Text("Espaço usado por downloads: $mbUsed", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { viewModel.clearAllDownloads() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Limpar todos os downloads")
                    }
                }
            }
        }

        // Integrações Externas (Gemini IA & Supabase)
        item {
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("APIs e Sincronização (Opcional)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    OutlinedTextField(
                        value = geminiKey,
                        onValueChange = { geminiKey = it; viewModel.setGeminiApiKey(it) },
                        label = { Text("Gemini API Key (Playlists IA)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = supabaseUrl,
                        onValueChange = { supabaseUrl = it; viewModel.setSupabaseUrl(it) },
                        label = { Text("Supabase Project URL (Sync Nuvem)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
