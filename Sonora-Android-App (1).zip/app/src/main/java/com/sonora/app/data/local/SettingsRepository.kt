package com.sonora.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sonora_settings")

data class UserSettings(
    val darkTheme: Boolean = true,
    val displayName: String = "Ouvinte Sonora",
    val audioQuality: String = "Alta (320 kbps)",
    val crossfadeSeconds: Int = 0,
    val normalizeVolume: Boolean = true,
    val wifiOnlyDownloads: Boolean = true,
    val offlineMode: Boolean = false,
    val eqPreset: String = "Flat",
    val bassBoostLevel: Int = 0,
    val djVoiceEnabled: Boolean = true,
    val geminiApiKey: String = "",
    val supabaseUrl: String = ""
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val DISPLAY_NAME = stringPreferencesKey("display_name")
        val AUDIO_QUALITY = stringPreferencesKey("audio_quality")
        val CROSSFADE = intPreferencesKey("crossfade_seconds")
        val NORMALIZE = booleanPreferencesKey("normalize_volume")
        val WIFI_ONLY = booleanPreferencesKey("wifi_only_downloads")
        val OFFLINE_MODE = booleanPreferencesKey("offline_mode")
        val EQ_PRESET = stringPreferencesKey("eq_preset")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val DJ_VOICE = booleanPreferencesKey("dj_voice")
        val GEMINI_KEY = stringPreferencesKey("gemini_api_key")
        val SUPABASE_URL = stringPreferencesKey("supabase_url")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            darkTheme = p[Keys.DARK_THEME] ?: true,
            displayName = p[Keys.DISPLAY_NAME] ?: "Ouvinte Sonora",
            audioQuality = p[Keys.AUDIO_QUALITY] ?: "Alta (320 kbps)",
            crossfadeSeconds = p[Keys.CROSSFADE] ?: 0,
            normalizeVolume = p[Keys.NORMALIZE] ?: true,
            wifiOnlyDownloads = p[Keys.WIFI_ONLY] ?: true,
            offlineMode = p[Keys.OFFLINE_MODE] ?: false,
            eqPreset = p[Keys.EQ_PRESET] ?: "Flat",
            bassBoostLevel = p[Keys.BASS_BOOST] ?: 0,
            djVoiceEnabled = p[Keys.DJ_VOICE] ?: true,
            geminiApiKey = p[Keys.GEMINI_KEY] ?: "",
            supabaseUrl = p[Keys.SUPABASE_URL] ?: ""
        )
    }

    suspend fun setDarkTheme(enabled: Boolean) { context.dataStore.edit { it[Keys.DARK_THEME] = enabled } }
    suspend fun setDisplayName(name: String) { context.dataStore.edit { it[Keys.DISPLAY_NAME] = name } }
    suspend fun setAudioQuality(q: String) { context.dataStore.edit { it[Keys.AUDIO_QUALITY] = q } }
    suspend fun setCrossfade(sec: Int) { context.dataStore.edit { it[Keys.CROSSFADE] = sec.coerceIn(0, 12) } }
    suspend fun setNormalizeVolume(enabled: Boolean) { context.dataStore.edit { it[Keys.NORMALIZE] = enabled } }
    suspend fun setWifiOnlyDownloads(enabled: Boolean) { context.dataStore.edit { it[Keys.WIFI_ONLY] = enabled } }
    suspend fun setOfflineMode(enabled: Boolean) { context.dataStore.edit { it[Keys.OFFLINE_MODE] = enabled } }
    suspend fun setEqPreset(preset: String) { context.dataStore.edit { it[Keys.EQ_PRESET] = preset } }
    suspend fun setBassBoost(level: Int) { context.dataStore.edit { it[Keys.BASS_BOOST] = level.coerceIn(0, 1000) } }
    suspend fun setDjVoice(enabled: Boolean) { context.dataStore.edit { it[Keys.DJ_VOICE] = enabled } }
    suspend fun setGeminiApiKey(key: String) { context.dataStore.edit { it[Keys.GEMINI_KEY] = key.trim() } }
    suspend fun setSupabaseUrl(url: String) { context.dataStore.edit { it[Keys.SUPABASE_URL] = url.trim() } }
}
