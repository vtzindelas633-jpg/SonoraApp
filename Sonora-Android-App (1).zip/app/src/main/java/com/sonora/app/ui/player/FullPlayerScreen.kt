package com.sonora.app.ui.player

import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.sonora.app.core.audio.AudioFxController
import com.sonora.app.core.theme.ObsidianBg
import com.sonora.app.core.theme.extractDominantColor
import com.sonora.app.core.theme.formatDuration
import com.sonora.app.ui.SonoraViewModel
import com.sonora.app.ui.components.TrackArtwork

private enum class PlayerPanel { MAIN, LYRICS, QUEUE, EQUALIZER }

@Composable
fun FullPlayerScreen(
    viewModel: SonoraViewModel,
    onCollapse: () -> Unit
) {
    val context = LocalContext.current
    val playback by viewModel.playbackState.collectAsState()
    val lyrics by viewModel.lyricsState.collectAsState()
    val isLyricsLoading by viewModel.isLyricsLoading.collectAsState()
    val eqBands by AudioFxController.bands.collectAsState()
    val eqPreset by AudioFxController.activePreset.collectAsState()
    val bassStrength by AudioFxController.bassStrength.collectAsState()

    val track = playback.currentTrack ?: return
    var activePanel by remember { mutableStateOf(PlayerPanel.MAIN) }
    var showTimerDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }

    // Dynamic album art background color
    var targetColor by remember { mutableStateOf(Color(0xFF1E293B)) }
    LaunchedEffect(track.artworkUri) {
        if (!track.artworkUri.isNullOrBlank()) {
            val loader = ImageLoader(context)
            val req = ImageRequest.Builder(context).data(track.artworkUri).allowHardware(false).build()
            val result = runCatching { loader.execute(req) }.getOrNull()
            val bmp = (result as? SuccessResult)?.drawable?.let { (it as? BitmapDrawable)?.bitmap }
            if (bmp != null) {
                targetColor = extractDominantColor(bmp)
            }
        } else {
            targetColor = Color(0xFF1E293B)
        }
    }
    val bgAccent by animateColorAsState(targetValue = targetColor, label = "playerBg")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(bgAccent, ObsidianBg, ObsidianBg)))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Minimizar", tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TOCANDO AGORA", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                    Text(track.album, style = MaterialTheme.typography.bodySmall, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = {
                    context.startActivity(viewModel.shareTextIntent(track.title, "Ouvindo ${track.title} - ${track.artist} no Sonora!"))
                }) {
                    Icon(Icons.Rounded.Share, "Compartilhar", tint = Color.White)
                }
            }

            // Panel Switcher Pills
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                FilterChip(selected = activePanel == PlayerPanel.MAIN, onClick = { activePanel = PlayerPanel.MAIN }, label = { Text("Capa") })
                FilterChip(selected = activePanel == PlayerPanel.LYRICS, onClick = { activePanel = PlayerPanel.LYRICS }, label = { Text("Letra") })
                FilterChip(selected = activePanel == PlayerPanel.QUEUE, onClick = { activePanel = PlayerPanel.QUEUE }, label = { Text("Fila") })
                FilterChip(selected = activePanel == PlayerPanel.EQUALIZER, onClick = { activePanel = PlayerPanel.EQUALIZER }, label = { Text("EQ") })
            }

            // Center Dynamic Content Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                when (activePanel) {
                    PlayerPanel.MAIN -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            TrackArtwork(artworkUri = track.artworkUri, size = 280.dp, cornerRadius = 24.dp)
                            if (playback.errorMessage != null) {
                                Spacer(Modifier.height(8.dp))
                                Text(playback.errorMessage!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    PlayerPanel.LYRICS -> {
                        if (isLyricsLoading) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        } else if (lyrics.syncedLines.isNotEmpty()) {
                            val listState = rememberLazyListState()
                            val activeIdx = remember(playback.positionMs, lyrics.syncedLines) {
                                lyrics.syncedLines.indexOfLast { it.timestampMs <= playback.positionMs }.coerceAtLeast(0)
                            }
                            LaunchedEffect(activeIdx) {
                                listState.animateScrollToItem(activeIdx.coerceAtLeast(0))
                            }
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize().padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                itemsIndexed(lyrics.syncedLines) { idx, line ->
                                    val isActive = idx == activeIdx
                                    Text(
                                        text = line.text,
                                        style = if (isActive) MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                        else MaterialTheme.typography.bodyLarge,
                                        color = if (isActive) Color.White else Color.White.copy(alpha = 0.45f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.playerController.seekTo(line.timestampMs) }
                                    )
                                }
                            }
                        } else if (lyrics.plainLyrics.isNotBlank()) {
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                item {
                                    Text(lyrics.plainLyrics, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        } else {
                            Text("Letra não disponível para esta faixa.", color = Color.White.copy(alpha = 0.65f))
                        }
                    }

                    PlayerPanel.QUEUE -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Fila (${playback.queue.size})", color = Color.White, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { viewModel.playerController.clearQueue() }) { Text("Limpar") }
                            }
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                itemsIndexed(playback.queue) { idx, item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.playerController.playTrackAt(idx) }
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TrackArtwork(item.artworkUri, size = 40.dp, cornerRadius = 8.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                item.title,
                                                color = if (idx == playback.currentIndex) MaterialTheme.colorScheme.primary else Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(item.artist, color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                        }
                                        IconButton(onClick = { viewModel.playerController.removeFromQueue(idx) }) {
                                            Icon(Icons.Rounded.Close, "Remover", tint = Color.White.copy(alpha = 0.6f))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    PlayerPanel.EQUALIZER -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Text("Presets do Equalizador", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(AudioFxController.customPresets.keys.toList()) { preset ->
                                        FilterChip(
                                            selected = eqPreset == preset,
                                            onClick = { AudioFxController.applyPreset(preset) },
                                            label = { Text(preset) }
                                        )
                                    }
                                }
                            }
                            items(eqBands) { band ->
                                Column {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${band.centerFreqHz} Hz", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                        Text("${band.levelMb / 100} dB", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Slider(
                                        value = band.levelMb.toFloat(),
                                        onValueChange = { AudioFxController.setBandLevel(band.index, it.toInt().toShort()) },
                                        valueRange = band.minMb.toFloat()..band.maxMb.toFloat()
                                    )
                                }
                            }
                            item {
                                Text("Reforço de Graves (Bass Boost): ${bassStrength / 10}%", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                Slider(
                                    value = bassStrength.toFloat(),
                                    onValueChange = { AudioFxController.setBassBoost(it.toInt()) },
                                    valueRange = 0f..1000f
                                )
                            }
                        }
                    }
                }
            }

            // Track Info + Favorite + Download
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.72f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { viewModel.downloadTrack(track) }) {
                    Icon(
                        if (track.isDownloaded) Icons.Rounded.DownloadDone else Icons.Rounded.Download,
                        "Baixar",
                        tint = if (track.isDownloaded) MaterialTheme.colorScheme.primary else Color.White
                    )
                }
                IconButton(onClick = { viewModel.toggleFavorite(track) }) {
                    Icon(
                        if (track.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        "Favoritar",
                        tint = if (track.isFavorite) MaterialTheme.colorScheme.primary else Color.White
                    )
                }
            }

            // Seekbar
            val duration = playback.durationMs.coerceAtLeast(1L)
            Slider(
                value = playback.positionMs.coerceIn(0L, duration).toFloat(),
                onValueChange = { viewModel.playerController.seekTo(it.toLong()) },
                valueRange = 0f..duration.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(playback.positionMs), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                Text(formatDuration(duration), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
            }

            // Main Transport Controls
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { viewModel.playerController.toggleShuffle() }) {
                    Icon(
                        Icons.Rounded.Shuffle,
                        "Aleatório",
                        tint = if (playback.shuffleEnabled) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.65f)
                    )
                }
                IconButton(onClick = { viewModel.playerController.skipPrevious() }) {
                    Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { viewModel.playerController.togglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    if (playback.isBuffering) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(26.dp), strokeWidth = 2.5.dp)
                    } else {
                        Icon(
                            if (playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            "Reproduzir ou Pausar",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
                IconButton(onClick = { viewModel.playerController.skipNext() }) {
                    Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White, modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { viewModel.playerController.cycleRepeatMode() }) {
                    val icon = if (playback.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
                    val active = playback.repeatMode != Player.REPEAT_MODE_OFF
                    Icon(icon, "Repetir", tint = if (active) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.65f))
                }
            }

            // Bottom Utility Bar (Speed, -10s/+10s, Sleep Timer)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { showSpeedDialog = true }) {
                    Text("${playback.playbackSpeed}x", color = Color.White)
                }
                IconButton(onClick = { viewModel.playerController.seekRelative(-10_000L) }) {
                    Icon(Icons.Rounded.Replay10, "Voltar 10s", tint = Color.White)
                }
                IconButton(onClick = { viewModel.playerController.seekRelative(10_000L) }) {
                    Icon(Icons.Rounded.Forward10, "Avançar 10s", tint = Color.White)
                }
                TextButton(onClick = { showTimerDialog = true }) {
                    Icon(Icons.Rounded.Timer, null, tint = if (playback.sleepTimerMinutesLeft != null) MaterialTheme.colorScheme.primary else Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(playback.sleepTimerMinutesLeft?.let { "${it}m" } ?: "Timer", color = Color.White)
                }
            }
        }
    }

    if (showTimerDialog) {
        val options = listOf(null to "Desativado", 15 to "15 minutos", 30 to "30 minutos", 45 to "45 minutos", 60 to "60 minutos")
        AlertDialog(
            onDismissRequest = { showTimerDialog = false },
            title = { Text("Temporizador de Desligamento") },
            text = {
                Column {
                    options.forEach { (min, label) ->
                        TextButton(
                            onClick = { viewModel.playerController.setSleepTimer(min); showTimerDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(label) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTimerDialog = false }) { Text("Fechar") } }
        )
    }

    if (showSpeedDialog) {
        val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Velocidade de Reprodução") },
            text = {
                Column {
                    speeds.forEach { s ->
                        TextButton(
                            onClick = { viewModel.playerController.setPlaybackSpeed(s); showSpeedDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("${s}x") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSpeedDialog = false }) { Text("Fechar") } }
        )
    }
}
