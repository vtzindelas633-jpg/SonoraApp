package com.sonora.app.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.sonora.app.ui.SonoraViewModel
import com.sonora.app.ui.components.SectionHeader
import com.sonora.app.ui.components.TrackArtwork
import com.sonora.app.ui.components.TrackRowItem

@Composable
fun SearchScreen(viewModel: SonoraViewModel) {
    val context = LocalContext.current
    val searchState by viewModel.searchState.collectAsState()
    val history by viewModel.searchHistory.collectAsState()
    val playback by viewModel.playbackState.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    val filters = listOf("Tudo", "Locais", "Online", "Podcasts", "Letras")

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Buscar",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 8.dp)
        )

        OutlinedTextField(
            value = searchState.query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Músicas, artistas, podcasts ou trecho da letra...") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (searchState.query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Rounded.Close, "Limpar")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { viewModel.executeSearch() }),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filters) { f ->
                FilterChip(
                    selected = searchState.activeFilter == f,
                    onClick = { viewModel.setSearchFilter(f) },
                    label = { Text(f) }
                )
            }
        }

        if (searchState.isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 140.dp)
        ) {
            if (searchState.query.isBlank() && history.isNotEmpty()) {
                item {
                    SectionHeader("Pesquisas recentes", actionLabel = "Limpar", onActionClick = { viewModel.clearSearchHistory() })
                }
                items(history) { q ->
                    ListItem(
                        headlineContent = { Text(q) },
                        leadingContent = { Icon(Icons.Rounded.History, null) },
                        modifier = Modifier.clickable { viewModel.executeSearch(q) }
                    )
                }
            }

            if ((searchState.activeFilter == "Tudo" || searchState.activeFilter == "Locais") && searchState.localResults.isNotEmpty()) {
                item { SectionHeader("Na sua Biblioteca Local") }
                itemsIndexed(searchState.localResults) { idx, track ->
                    TrackRowItem(
                        track = track,
                        isCurrent = playback.currentTrack?.id == track.id,
                        playlists = playlists,
                        onClick = { viewModel.playTrackList(searchState.localResults, idx) },
                        onFavoriteClick = { viewModel.toggleFavorite(track) },
                        onAddToQueue = { viewModel.playerController.addToQueue(track) },
                        onPlayNext = { viewModel.playerController.playNext(track) },
                        onDownloadClick = { viewModel.downloadTrack(track) },
                        onAddToPlaylist = { plId -> viewModel.addTrackToPlaylist(plId, track) },
                        onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                    )
                }
            }

            if ((searchState.activeFilter == "Tudo" || searchState.activeFilter == "Online") && searchState.onlineResults.isNotEmpty()) {
                item { SectionHeader("Catálogo Online (Streaming)") }
                itemsIndexed(searchState.onlineResults) { idx, track ->
                    TrackRowItem(
                        track = track,
                        isCurrent = playback.currentTrack?.id == track.id,
                        playlists = playlists,
                        onClick = { viewModel.playTrackList(searchState.onlineResults, idx) },
                        onFavoriteClick = { viewModel.toggleFavorite(track) },
                        onAddToQueue = { viewModel.playerController.addToQueue(track) },
                        onPlayNext = { viewModel.playerController.playNext(track) },
                        onDownloadClick = { viewModel.downloadTrack(track) },
                        onAddToPlaylist = { plId -> viewModel.addTrackToPlaylist(plId, track) },
                        onShareClick = { context.startActivity(viewModel.shareTextIntent(track.title, "${track.title} - ${track.artist}")) }
                    )
                }
            }

            if ((searchState.activeFilter == "Tudo" || searchState.activeFilter == "Podcasts") && searchState.podcastResults.isNotEmpty()) {
                item { SectionHeader("Podcasts") }
                items(searchState.podcastResults) { show ->
                    ListItem(
                        headlineContent = { Text(show.title) },
                        supportingContent = { Text("${show.author} • ${show.genre}") },
                        leadingContent = { TrackArtwork(show.artworkUrl, size = 48.dp, cornerRadius = 8.dp) },
                        modifier = Modifier.clickable { viewModel.loadPodcastEpisodes(show) }
                    )
                }
            }

            if ((searchState.activeFilter == "Tudo" || searchState.activeFilter == "Letras") && searchState.lyricMatches.isNotEmpty()) {
                item { SectionHeader("Músicas encontradas pela letra") }
                items(searchState.lyricMatches) { (song, artist) ->
                    ListItem(
                        headlineContent = { Text(song) },
                        supportingContent = { Text(artist) },
                        leadingContent = { Icon(Icons.Rounded.Lyrics, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { viewModel.executeSearch("$song $artist") }
                    )
                }
            }
        }
    }
}
